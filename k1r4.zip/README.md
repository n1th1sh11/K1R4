# K1r4

A terminal-style, ephemeral, realtime communication node for the digital underground.

## Quick Start (Frontend Demo)
1. Install dependencies: `npm install`
2. Run development server: `npm run dev`
3. The app runs in "Demo Mode" by default (no backend needed).

## Backend Setup
To run the real socket server:
1. Navigate to `backend/` directory.
2. Run `npm install`
3. Run `node server.js`
4. In `constants.ts`, change `DEMO_MODE` to `false`.
5. Ensure `SOCKET_URL` matches your backend address.

## Deployment
- **Frontend**: Deploy to Vercel/Netlify.
- **Backend**: Deploy Dockerfile to Railway/Render.
