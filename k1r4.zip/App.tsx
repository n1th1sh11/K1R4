

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { v4 as uuidv4 } from 'uuid';
import MatrixRain from './components/MatrixRain';
import TerminalInput from './components/TerminalInput';
import MessageList from './components/MessageList';
import GlitchText from './components/GlitchText';
import { initSocket, getSocket } from './services/socket';
import { Message, MessageType, User } from './types';
import { HELP_TEXT, WELCOME_MESSAGE, DEMO_MODE } from './constants';
import { 
  UserGroupIcon, 
  LockClosedIcon, 
  SignalIcon, 
  ClipboardDocumentIcon, 
  CheckIcon,
  ClockIcon,
  MinusCircleIcon,
  ChatBubbleLeftRightIcon
} from '@heroicons/react/24/outline';

const App: React.FC = () => {
  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [nickname, setNickname] = useState('');
  const [roomId, setRoomId] = useState('');
  const [joined, setJoined] = useState(false);
  const [users, setUsers] = useState<User[]>([]);
  const [matrixEnabled, setMatrixEnabled] = useState(true);
  const [loading, setLoading] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  // Initial Setup
  useEffect(() => {
    // Check local storage but don't force it if user wants to change
    const storedNick = localStorage.getItem('k1r4_identity');
    if (storedNick) {
      setNickname(storedNick);
    }

    // Check URL for Room ID
    const pathRoom = window.location.hash.replace('#/', '');
    if (pathRoom) {
      setRoomId(pathRoom);
    } else {
      const newRoom = uuidv4().slice(0, 8);
      setRoomId(newRoom);
      window.location.hash = `/${newRoom}`;
    }
  }, []);

  const addSystemMessage = useCallback((text: string, type: MessageType = MessageType.SYSTEM) => {
    setMessages(prev => [...prev, {
      id: uuidv4(),
      text,
      type,
      timestamp: Date.now()
    }]);
  }, []);

  const handleJoin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!nickname.trim()) return;
    
    setLoading(true);

    const socket = initSocket(roomId, nickname);

    socket.on('connect', () => {
      setConnected(true);
      setLoading(false);
      setJoined(true);
      addSystemMessage(WELCOME_MESSAGE);
    });

    socket.on('connect_error', (err: any) => {
      console.error("Connection Failed:", err);
      setLoading(false);
      addSystemMessage("CONNECTION FAILED. CHECK SERVER STATUS.", MessageType.ERROR);
    });

    socket.on('message', (msg: Message) => {
      setMessages(prev => [...prev, msg]);
    });

    socket.on('room_state', (state: { users: User[] }) => {
      setUsers(state.users);
    });

    socket.on('disconnect', () => {
      setConnected(false);
      addSystemMessage("SIGNAL LOST. RE-ESTABLISHING UPLINK...", MessageType.ERROR);
    });

    localStorage.setItem('k1r4_identity', nickname);
  };

  const processCommand = (text: string) => {
    // Improved parsing to handle multiple spaces
    const parts = text.slice(1).trim().split(/\s+/);
    const cmd = parts[0];
    const args = parts.slice(1);
    
    switch (cmd.toLowerCase()) {
      case 'clear':
        setMessages([]);
        break;
      case 'nick':
        const newNick = args[0];
        if (newNick) {
          setNickname(newNick);
          localStorage.setItem('k1r4_identity', newNick);
          getSocket().emit('command', { command: 'nick', value: newNick });
          addSystemMessage(`Identity rewritten: ${newNick}`);
        } else {
          addSystemMessage('USAGE: /nick <alias>', MessageType.ERROR);
        }
        break;
      case 'whisper':
        if (args.length < 2) {
          addSystemMessage('USAGE: /whisper <target_node> <message>', MessageType.ERROR);
          return;
        }
        getSocket().emit('command', { command: cmd, args });
        break;
      case 'theme':
        if (args[0] === 'matrix') setMatrixEnabled(true);
        else if (args[0] === 'retro') setMatrixEnabled(false);
        else {
           addSystemMessage('USAGE: /theme <matrix|retro>', MessageType.ERROR);
           return;
        }
        addSystemMessage(`Visual cortex updated: ${args[0]}`);
        break;
      case 'help':
        addSystemMessage(HELP_TEXT);
        break;
      default:
        // Pass to server for other commands like kick, status, or unknown ones
        if (cmd) {
           getSocket().emit('command', { command: cmd, args });
        }
        break;
    }
  };

  const handleSend = (text: string) => {
    if (text.startsWith('/')) {
      processCommand(text);
    } else {
      getSocket().emit('message', { text });
    }
  };

  const copyLink = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case 'AWAY': return <ClockIcon className="w-3 h-3 text-yellow-500" title="AWAY" />;
      case 'BUSY': return <MinusCircleIcon className="w-3 h-3 text-red-500" title="BUSY" />;
      case 'WHISPERING': return <ChatBubbleLeftRightIcon className="w-3 h-3 text-purple-500" title="WHISPERING" />;
      case 'ONLINE': default: return <SignalIcon className="w-3 h-3 text-hacker-green" title="ONLINE" />;
    }
  };

  const getStatusColor = (status?: string) => {
    switch (status) {
      case 'AWAY': return 'text-yellow-500';
      case 'BUSY': return 'text-red-500';
      case 'WHISPERING': return 'text-purple-500';
      case 'ONLINE': default: return 'bg-hacker-green'; // used for mobile dot
    }
  };

  // Sort users: Owner first, then alphabetical
  const sortedUsers = useMemo(() => {
    return [...users].sort((a, b) => {
      if (a.isOwner && !b.isOwner) return -1;
      if (!a.isOwner && b.isOwner) return 1;
      return a.nickname.localeCompare(b.nickname);
    });
  }, [users]);

  if (!joined) {
    return (
      <div className="min-h-screen bg-black text-hacker-green font-mono flex flex-col items-center justify-center p-4 relative overflow-hidden">
        <MatrixRain active={true} />
        <div className="absolute inset-0 crt-overlay pointer-events-none z-20"></div>
        
        <div className="z-30 max-w-md w-full border border-hacker-green bg-black/95 p-8 shadow-[0_0_30px_rgba(0,255,65,0.2)] backdrop-blur-sm">
          <div className="text-center mb-10">
            <GlitchText text="K1r4 // NEURAL LINK" as="h1" className="text-5xl font-bold mb-2 tracking-tighter text-glow" />
            <p className="text-xs uppercase tracking-[0.3em] text-neon-blue opacity-80">Decentralized Comms Node</p>
          </div>

          <form onSubmit={handleJoin} className="space-y-6">
            <div className="relative group">
              <label className="block text-[10px] uppercase tracking-widest mb-1 text-gray-500 group-focus-within:text-hacker-green transition-colors">Target Frequency (Room)</label>
              <div className="flex bg-hacker-dark/50 border-b border-gray-700 group-focus-within:border-hacker-green transition-colors p-2 items-center">
                <LockClosedIcon className="w-4 h-4 mr-3 opacity-50" />
                <input 
                  type="text" 
                  value={roomId}
                  onChange={(e) => setRoomId(e.target.value)}
                  className="bg-transparent w-full outline-none font-mono text-lg text-white placeholder-gray-800"
                  placeholder="AUTO-GENERATED"
                />
                <button
                  type="button"
                  onClick={copyLink}
                  className="ml-2 p-1 hover:text-white transition-colors text-gray-500"
                  title="Copy Link to Clipboard"
                >
                  {copied ? <CheckIcon className="w-5 h-5 text-hacker-green" /> : <ClipboardDocumentIcon className="w-5 h-5" />}
                </button>
              </div>
              <div className="text-[10px] text-gray-600 mt-1 pl-1">Share this ID to invite other nodes.</div>
            </div>

            <div className="relative group">
              <label className="block text-[10px] uppercase tracking-widest mb-1 text-gray-500 group-focus-within:text-neon-blue transition-colors">Identity (Alias)</label>
              <div className="flex bg-hacker-dark/50 border-b border-gray-700 group-focus-within:border-neon-blue transition-colors p-2 items-center">
                <UserGroupIcon className="w-4 h-4 mr-3 opacity-50" />
                <input 
                  type="text" 
                  value={nickname}
                  onChange={(e) => setNickname(e.target.value)}
                  className="bg-transparent w-full outline-none font-mono text-lg text-neon-blue placeholder-gray-800"
                  placeholder="ENTER_ALIAS_"
                  maxLength={15}
                  autoFocus
                />
              </div>
            </div>

            <button 
              type="submit"
              disabled={loading || !nickname.trim()}
              className="w-full mt-4 bg-hacker-green text-black font-bold py-4 hover:bg-white hover:text-black transition-all uppercase tracking-widest disabled:opacity-30 disabled:cursor-not-allowed text-sm flex justify-center items-center group"
            >
              {loading ? (
                <span className="animate-pulse">ESTABLISHING LINK...</span>
              ) : (
                <>
                  INITIALIZE <SignalIcon className="w-4 h-4 ml-2 group-hover:animate-ping" />
                </>
              )}
            </button>
          </form>

          {DEMO_MODE && (
             <div className="mt-6 text-[10px] text-center text-gray-600 font-mono">
               [ STANDALONE MODE: OPEN NEW TAB TO TEST CHAT ]
             </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-black overflow-hidden relative font-mono text-sm sm:text-base">
      <MatrixRain active={matrixEnabled} />
      <div className="absolute inset-0 crt-overlay pointer-events-none z-20"></div>

      {/* Header */}
      <div className="relative z-30 bg-black/80 border-b border-hacker-dim p-3 flex justify-between items-center text-xs backdrop-blur-sm">
        <div className="flex items-center space-x-4">
           <div className="flex flex-col">
             <span className="font-bold text-hacker-green text-lg tracking-tight leading-none">K1r4</span>
             <button 
               onClick={copyLink} 
               className="text-[9px] text-gray-500 tracking-widest uppercase hover:text-white transition-colors flex items-center gap-1 text-left"
               title="Click to copy link"
             >
               Node: {roomId}
               {copied ? <CheckIcon className="w-3 h-3 text-hacker-green" /> : <ClipboardDocumentIcon className="w-3 h-3" />}
             </button>
           </div>
        </div>
        <div className="flex items-center">
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex items-center text-neon-blue hover:text-white transition-colors focus:outline-none md:cursor-default bg-hacker-dark/50 px-3 py-1 border border-hacker-dim rounded-sm"
          >
             <span className="w-1.5 h-1.5 rounded-full bg-neon-blue animate-pulse mr-2 shadow-[0_0_5px_#00f3ff]"></span>
             <span className="tracking-widest">{users.length} ONLINE</span>
             <UserGroupIcon className="w-4 h-4 ml-2 md:hidden" />
          </button>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 relative z-30 flex overflow-hidden">
        <MessageList messages={messages} />
        
        {/* Desktop Sidebar (Users) */}
        <div className="hidden md:block w-56 border-l border-hacker-dim bg-black/60 p-4 overflow-y-auto backdrop-blur-sm">
          <h3 className="text-gray-500 font-bold mb-4 text-[10px] uppercase tracking-[0.2em] border-b border-gray-800 pb-2">
            Connected Nodes
          </h3>
          <ul className="space-y-3">
            {sortedUsers.map(u => (
              <li key={u.id} className="flex items-center group cursor-default">
                <span className={`w-1 h-full mr-2 transition-all ${u.isOwner ? 'bg-yellow-500 h-3' : 'bg-hacker-green h-2 group-hover:h-3'}`}></span>
                <span className={`${u.isOwner ? 'text-yellow-400' : 'text-gray-400 group-hover:text-neon-blue'} text-xs tracking-wider truncate transition-colors flex-1`}>
                  {u.nickname}
                </span>
                
                {/* Status Icon */}
                <div className="ml-2">
                   {getStatusIcon(u.status)}
                </div>

                {u.isOwner && <span className="ml-1 text-[8px] text-yellow-600">[ROOT]</span>}
              </li>
            ))}
          </ul>
        </div>

        {/* Mobile User List Overlay */}
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-[60] bg-black/95 flex flex-col md:hidden animate-[fadeIn_0.2s_ease-out]">
            <div className="flex justify-between items-center p-4 border-b border-hacker-green bg-hacker-dim/20">
              <span className="text-hacker-green font-bold tracking-widest">>> CONNECTED_NODES</span>
              <button 
                onClick={() => setMobileMenuOpen(false)}
                className="text-hacker-green hover:text-white font-bold"
              >
                [X]
              </button>
            </div>
            <div className="p-4 overflow-y-auto flex-1">
              <ul className="space-y-4">
                {sortedUsers.map(u => (
                  <li key={u.id} className="flex items-center space-x-3 border-b border-gray-900 pb-3 last:border-0">
                    <span className={`w-2 h-2 rounded-full ${u.isOwner ? 'bg-yellow-400' : getStatusColor(u.status)} shadow-[0_0_8px_rgba(0,243,255,0.4)]`}></span>
                    <div className="flex flex-1 items-center justify-between">
                        <span className={`${u.isOwner ? 'text-yellow-400' : 'text-gray-300'} font-mono text-lg tracking-wide`}>
                        {u.nickname} 
                        </span>
                        {getStatusIcon(u.status)}
                    </div>
                    {u.isOwner && <span className="text-xs bg-yellow-900/30 text-yellow-500 px-1 rounded ml-2">ADMIN</span>}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="relative z-40">
        <TerminalInput onSend={handleSend} nickname={nickname} disabled={!connected} />
      </div>
    </div>
  );
};

export default App;
