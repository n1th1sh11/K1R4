
export type UserStatus = 'ONLINE' | 'AWAY' | 'BUSY' | 'WHISPERING';

export interface User {
  id: string;
  nickname: string;
  isOwner?: boolean;
  color?: string;
  status?: UserStatus;
}

export enum MessageType {
  USER = 'USER',
  SYSTEM = 'SYSTEM',
  WHISPER = 'WHISPER',
  ERROR = 'ERROR',
  GLITCH = 'GLITCH'
}

export interface Message {
  id: string;
  text: string;
  sender?: string;
  type: MessageType;
  timestamp: number;
  selfDestruct?: number; // timestamp to delete
}

export interface RoomState {
  id: string;
  users: User[];
  locked: boolean;
  createdAt: number;
}

export interface CommandResult {
  success: boolean;
  message?: string;
  action?: 'CLEAR' | 'THEME' | 'NONE';
  payload?: any;
}
