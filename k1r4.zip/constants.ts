

// Toggle this to FALSE when connecting to a real backend
export const DEMO_MODE = true; 

export const SOCKET_URL = (import.meta as any).env?.VITE_SOCKET_URL || 'http://localhost:3001';

export const COLORS = [
  '#00ff41', // Matrix Green
  '#00f3ff', // Cyber Blue
  '#ff00ff', // Neon Purple
  '#f0f0f0', // White/Grey
  '#ffff00', // Yellow
];

export const HELP_TEXT = `
K1r4 PROTOCOLS v2.2
-------------------
/nick <alias>           : Rewrite identity
/status <mode>          : Set status (online|away|busy|whispering)
/away                   : Set status to AWAY
/whisper <name> <msg>   : Encrypted p2p signal
/clear                  : Flush terminal buffer
/theme <matrix|retro>   : Toggle visual cortex
/help                   : Access this manual

ADMIN OVERRIDE:
/kick <node>            : Force disconnect
/lock                   : Seal room entry
`;

export const WELCOME_MESSAGE = `
K1r4 TERMINAL UPLINK [SECURE]
-----------------------------------------------
> ENCRYPTION: 256-BIT AES-GCM
> CHANNEL STATUS: OPEN
> TESTING: OPEN A NEW TAB WITH SAME URL TO CHAT
-----------------------------------------------
Identity verification complete.
Welcome to the underground. Type /help for protocols.
`;
