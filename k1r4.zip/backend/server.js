
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "*", 
    methods: ["GET", "POST"]
  }
});

// Memory Store
const rooms = {}; // { roomId: { users: [], locked: false, lastActivity: ts } }

// Helper to clean empty rooms
setInterval(() => {
  const now = Date.now();
  Object.keys(rooms).forEach(rid => {
    // Expire after 1 hour of inactivity if empty, or 6 hours max
    if (rooms[rid].users.length === 0 && now - rooms[rid].lastActivity > 3600000) {
      delete rooms[rid];
      console.log(`Pruned room ${rid}`);
    }
  });
}, 60000);

io.on('connection', (socket) => {
  const { roomId, nickname } = socket.handshake.query;

  if (!roomId || !nickname) {
    socket.disconnect();
    return;
  }

  // Join/Create Room
  if (!rooms[roomId]) {
    rooms[roomId] = {
      id: roomId,
      users: [],
      locked: false,
      lastActivity: Date.now(),
      ownerId: socket.id
    };
  }

  const room = rooms[roomId];

  if (room.locked) {
    socket.emit('error', 'Room is locked.');
    socket.disconnect();
    return;
  }

  // Add User
  const user = { 
    id: socket.id, 
    nickname: nickname.slice(0, 15), 
    isOwner: room.ownerId === socket.id,
    status: 'ONLINE' 
  };
  room.users.push(user);
  socket.join(roomId);

  // Broadcast Update
  io.to(roomId).emit('room_state', { users: room.users });
  io.to(roomId).emit('message', {
    id: uuidv4(),
    text: `Node ${user.nickname} has joined the grid.`,
    type: 'SYSTEM',
    timestamp: Date.now()
  });

  // Handle Messages
  socket.on('message', (data) => {
    rooms[roomId].lastActivity = Date.now();
    const msg = {
      id: uuidv4(),
      text: data.text.slice(0, 500), // Max length
      sender: user.nickname,
      type: 'USER',
      timestamp: Date.now()
    };
    io.to(roomId).emit('message', msg);
  });

  // Handle Commands
  socket.on('command', (data) => {
    const { command, args, value } = data;
    
    if (command === 'nick') {
      const u = room.users.find(u => u.id === socket.id);
      if (u) {
        const old = u.nickname;
        u.nickname = value.slice(0, 15);
        io.to(roomId).emit('room_state', { users: room.users });
        io.to(roomId).emit('message', {
          id: uuidv4(),
          text: `Node ${old} rewrote identity to ${u.nickname}`,
          type: 'SYSTEM',
          timestamp: Date.now()
        });
      }
    } else if (['status', 'away', 'busy'].includes(command)) {
        let newStatus = 'ONLINE';
        if (command === 'away') newStatus = 'AWAY';
        else if (command === 'busy') newStatus = 'BUSY';
        else if (args && args[0]) newStatus = args[0].toUpperCase();
        
        const allowed = ['ONLINE', 'AWAY', 'BUSY', 'WHISPERING'];
        if (!allowed.includes(newStatus)) newStatus = 'ONLINE';
        
        const u = room.users.find(u => u.id === socket.id);
        if (u) {
            u.status = newStatus;
            io.to(roomId).emit('room_state', { users: room.users });
        }
    } else if (command === 'whisper') {
      const targetNick = args[0];
      const text = args.slice(1).join(' ');

      if (!targetNick || !text) {
        socket.emit('message', {
          id: uuidv4(),
          text: 'Usage: /whisper <nickname> <message>',
          type: 'ERROR',
          timestamp: Date.now()
        });
        return;
      }

      const targetUser = room.users.find(u => u.nickname === targetNick);

      if (!targetUser) {
        socket.emit('message', {
          id: uuidv4(),
          text: `Target node '${targetNick}' not found.`,
          type: 'ERROR',
          timestamp: Date.now()
        });
        return;
      }

      // Send to target
      io.to(targetUser.id).emit('message', {
        id: uuidv4(),
        text: text,
        sender: user.nickname,
        type: 'WHISPER',
        timestamp: Date.now()
      });

      // Confirm to sender
      socket.emit('message', {
        id: uuidv4(),
        text: text,
        sender: `You -> ${targetNick}`,
        type: 'WHISPER',
        timestamp: Date.now()
      });
    } else {
        // Unknown command
        socket.emit('message', {
          id: uuidv4(),
          text: `Command protocol mismatch: /${command}`,
          type: 'ERROR',
          timestamp: Date.now()
        });
    }
  });

  // Disconnect
  socket.on('disconnect', () => {
    const r = rooms[roomId];
    if (r) {
      r.users = r.users.filter(u => u.id !== socket.id);
      io.to(roomId).emit('room_state', { users: r.users });
      io.to(roomId).emit('message', {
        id: uuidv4(),
        text: `Node ${user.nickname} connection terminated.`,
        type: 'SYSTEM',
        timestamp: Date.now()
      });
      if (r.users.length === 0) {
        // Mark for potential cleanup
      }
    }
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`K1r4 Backend Server running on port ${PORT}`);
});
