

import { io, Socket } from 'socket.io-client';
import { DEMO_MODE, SOCKET_URL } from '../constants';
import { Message, MessageType, User } from '../types';

// Mock Socket for frontend-only demo with Multi-Tab support (BroadcastChannel)
class MockSocket {
  listeners: Record<string, Function[]> = {};
  id = 'node_' + Math.random().toString(36).substring(2, 9);
  connected = false;
  channel: BroadcastChannel;
  nickname: string = '';
  roomId: string = '';
  
  // Local state of users in the current room (across tabs)
  knownUsers: Record<string, User> = {};

  constructor() {
    // Create a local channel to talk to other tabs
    this.channel = new BroadcastChannel('k1r4_local_net');
    
    this.channel.onmessage = (event) => {
      this.handleChannelMessage(event.data);
    };
  }

  on(event: string, callback: Function) {
    if (!this.listeners[event]) this.listeners[event] = [];
    this.listeners[event].push(callback);
  }

  off(event: string, callback: Function) {
    if (!this.listeners[event]) return;
    this.listeners[event] = this.listeners[event].filter(cb => cb !== callback);
  }

  // Handle outgoing events (from App to Socket)
  emit(event: string, data: any) {
    setTimeout(() => {
      this.handleLocalEmit(event, data);
    }, 10);
  }

  // Logic to process events sent by this tab
  handleLocalEmit(event: string, data: any) {
    if (event === 'join') {
      this.nickname = data.nickname;
      this.roomId = data.roomId;
      
      // Register self
      const me: User = { 
        id: this.id, 
        nickname: this.nickname, 
        isOwner: true,
        status: 'ONLINE'
      };
      this.knownUsers[this.id] = me;

      // Broadcast presence to other tabs
      this.channel.postMessage({
        type: 'JOIN',
        user: me,
        roomId: this.roomId
      });

      // Ask who else is here
      this.channel.postMessage({
        type: 'WHO_IS_THERE',
        roomId: this.roomId,
        requesterId: this.id
      });

      // Update local UI
      this.trigger('room_state', { users: Object.values(this.knownUsers) });
      this.trigger('message', {
        id: Date.now().toString(),
        text: `You joined the channel as ${this.nickname}.`,
        type: MessageType.SYSTEM,
        timestamp: Date.now()
      });
    }

    if (event === 'message') {
      const msg: Message = {
        id: Date.now().toString() + Math.random(),
        text: data.text,
        sender: this.nickname,
        type: MessageType.USER,
        timestamp: Date.now()
      };
      
      // Show in own UI
      this.trigger('message', msg);
      
      // Send to other tabs
      this.channel.postMessage({
        type: 'MESSAGE',
        message: msg,
        roomId: this.roomId
      });
    }

    if (event === 'command') {
      const { command, args, value } = data;
      
      if (command === 'whisper') {
        const targetNick = args[0];
        const text = args.slice(1).join(' ');
        
        // Validation: Check if target exists
        const targetUser = Object.values(this.knownUsers).find(u => u.nickname === targetNick);
        
        if (!targetUser) {
           this.trigger('message', {
              id: Date.now().toString(),
              text: `Target node '${targetNick}' not found in local sector.`,
              type: MessageType.ERROR,
              timestamp: Date.now()
           });
           return;
        }

        // Local echo
        this.trigger('message', {
          id: Date.now().toString(),
          text: text,
          sender: `You -> ${targetNick}`,
          type: MessageType.WHISPER,
          timestamp: Date.now()
        });

        // Send to network so target can see it
        this.channel.postMessage({
          type: 'WHISPER',
          targetNick: targetNick,
          text: text,
          sender: this.nickname,
          roomId: this.roomId
        });
      } else if (command === 'nick') {
        const newNick = value;
        this.nickname = newNick;
        if (this.knownUsers[this.id]) {
            this.knownUsers[this.id].nickname = newNick;
        }
        
        this.trigger('room_state', { users: Object.values(this.knownUsers) });
        this.trigger('message', {
            id: Date.now().toString(),
            text: `Identity rewritten: ${newNick}`,
            type: MessageType.SYSTEM,
            timestamp: Date.now()
         });

         this.channel.postMessage({
             type: 'UPDATE_USER',
             user: this.knownUsers[this.id],
             roomId: this.roomId
         });
      } else if (['status', 'away', 'busy'].includes(command)) {
         let newStatus: any = 'ONLINE';
         if (command === 'away') newStatus = 'AWAY';
         else if (command === 'busy') newStatus = 'BUSY';
         else if (args && args[0]) newStatus = args[0].toUpperCase();
         
         const valid = ['ONLINE', 'AWAY', 'BUSY', 'WHISPERING'];
         if (!valid.includes(newStatus)) newStatus = 'ONLINE';

         if (this.knownUsers[this.id]) {
            this.knownUsers[this.id].status = newStatus;
            
            // Broadcast update
            this.channel.postMessage({
                type: 'UPDATE_USER',
                user: this.knownUsers[this.id],
                roomId: this.roomId
            });
            
            // Local update
            this.trigger('room_state', { users: Object.values(this.knownUsers) });
            this.trigger('message', {
                id: Date.now().toString(),
                text: `Status set to: ${newStatus}`,
                type: MessageType.SYSTEM,
                timestamp: Date.now()
            });
         }
      } else {
         // Handle unknown commands locally
         this.trigger('message', {
            id: Date.now().toString(),
            text: `Command not recognized: /${command}`,
            type: MessageType.ERROR,
            timestamp: Date.now()
         });
      }
    }
  }

  // Logic to handle events coming from OTHER tabs
  handleChannelMessage(data: any) {
    if (data.roomId !== this.roomId) return; // Ignore other rooms

    switch (data.type) {
      case 'JOIN':
        // Another user joined
        if (!this.knownUsers[data.user.id]) {
          this.knownUsers[data.user.id] = data.user;
          this.trigger('room_state', { users: Object.values(this.knownUsers) });
          this.trigger('message', {
            id: Date.now().toString(),
            text: `${data.user.nickname} connected.`,
            type: MessageType.SYSTEM,
            timestamp: Date.now()
          });
          
          // Announce myself to them so they know I exist
          this.channel.postMessage({
             type: 'I_AM_HERE',
             user: this.knownUsers[this.id],
             roomId: this.roomId,
             targetId: data.user.id
          });
        }
        break;

      case 'WHO_IS_THERE':
        // Someone is asking for user list
        if (this.knownUsers[this.id]) {
            this.channel.postMessage({
                type: 'I_AM_HERE',
                user: this.knownUsers[this.id],
                roomId: this.roomId,
                targetId: data.requesterId
            });
        }
        break;

      case 'I_AM_HERE':
        // A response to my presence check
        if (!this.knownUsers[data.user.id]) {
            this.knownUsers[data.user.id] = data.user;
            this.trigger('room_state', { users: Object.values(this.knownUsers) });
        }
        break;

      case 'MESSAGE':
        this.trigger('message', data.message);
        break;

      case 'WHISPER':
        // Only show if I am the target
        if (data.targetNick === this.nickname) {
            this.trigger('message', {
                id: Date.now().toString(),
                text: data.text,
                sender: data.sender,
                type: MessageType.WHISPER,
                timestamp: Date.now()
            });
        }
        break;
        
      case 'UPDATE_USER':
        if (this.knownUsers[data.user.id]) {
            // Check if status changed or just name
            const oldUser = this.knownUsers[data.user.id];
            this.knownUsers[data.user.id] = data.user;
            
            this.trigger('room_state', { users: Object.values(this.knownUsers) });
            
            if (oldUser.nickname !== data.user.nickname) {
              this.trigger('message', {
                  id: Date.now().toString(),
                  text: `${oldUser.nickname} changed ID to ${data.user.nickname}`,
                  type: MessageType.SYSTEM,
                  timestamp: Date.now()
              });
            }
        }
        break;
    }
  }

  trigger(event: string, data: any) {
    if (this.listeners[event]) {
      this.listeners[event].forEach(cb => cb(data));
    }
  }

  disconnect() {
    this.listeners = {};
    this.connected = false;
    this.channel.close();
  }
}

let socket: Socket | any;

export const initSocket = (roomId: string, nickname: string) => {
  if (DEMO_MODE) {
    console.log("INITIALIZING K1R4 P2P LOCAL NETWORK");
    const mockSocket = new MockSocket();
    socket = mockSocket;
    
    // Simulate connection delay then success
    setTimeout(() => {
        mockSocket.connected = true;
        mockSocket.trigger('connect', {});
        mockSocket.emit('join', { roomId, nickname });
    }, 300);
    
  } else {
    socket = io(SOCKET_URL, {
      query: { roomId, nickname },
      transports: ['websocket']
    });
  }
  return socket;
};

export const getSocket = () => socket;
