import React, { useEffect, useRef } from 'react';
import { Message, MessageType } from '../types';

interface MessageListProps {
  messages: Message[];
}

const formatTime = (ts: number) => {
  return new Date(ts).toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });
};

const MessageItem: React.FC<{ msg: Message }> = ({ msg }) => {
  const isSystem = msg.type === MessageType.SYSTEM;
  const isError = msg.type === MessageType.ERROR;
  const isWhisper = msg.type === MessageType.WHISPER;
  
  let textColor = 'text-hacker-green';
  if (isSystem) textColor = 'text-yellow-400';
  if (isError) textColor = 'text-red-500';
  if (isWhisper) textColor = 'text-purple-400 italic';

  return (
    <div className={`mb-2 font-mono break-words ${isSystem ? 'opacity-80' : ''}`}>
      <span className="text-gray-500 text-xs mr-2 select-none">[{formatTime(msg.timestamp)}]</span>
      
      {!isSystem && !isError && !isWhisper && (
        <span className="font-bold mr-2 text-hacker-green">
          &lt;{msg.sender || 'UNKNOWN'}&gt;
        </span>
      )}

      {isSystem && <span className="mr-2 text-yellow-500">! SYSTEM:</span>}
      {isError && <span className="mr-2 text-red-500">X ERROR:</span>}
      
      {isWhisper && (
         <span className="mr-2 text-purple-400 font-bold">
            [P2P] &lt;{msg.sender}&gt;:
         </span>
      )}

      <span className={`${textColor} text-glow`}>{msg.text}</span>
    </div>
  );
};

const MessageList: React.FC<MessageListProps> = ({ messages }) => {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className="flex-1 overflow-y-auto p-4 pb-24 sm:p-6 custom-scrollbar">
      {messages.map((msg) => (
        <MessageItem key={msg.id} msg={msg} />
      ))}
      <div ref={bottomRef} />
    </div>
  );
};

export default MessageList;