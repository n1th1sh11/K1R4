import React, { useState, useRef, useEffect } from 'react';
import { PaperAirplaneIcon } from '@heroicons/react/24/solid';

interface TerminalInputProps {
  onSend: (text: string) => void;
  nickname: string;
  disabled?: boolean;
}

const TerminalInput: React.FC<TerminalInputProps> = ({ onSend, nickname, disabled }) => {
  const [input, setInput] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!disabled) {
      inputRef.current?.focus();
    }
  }, [disabled]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim()) {
      onSend(input);
      setInput('');
    }
  };

  return (
    <form 
      onSubmit={handleSubmit} 
      className="flex items-center w-full bg-hacker-dark border-t border-hacker-dim p-2 sm:p-4 fixed bottom-0 left-0 z-50 shadow-[0_-5px_20px_rgba(0,0,0,0.8)]"
    >
      <div className="hidden sm:flex items-center text-neon-blue mr-3 font-mono select-none text-sm tracking-tight opacity-90">
        <span className="font-bold">{nickname}</span>
        <span className="text-gray-500">@</span>
        <span className="text-hacker-green">k1r4</span>
        <span className="mx-1 text-gray-400">:~$</span>
      </div>
      <div className="flex sm:hidden text-hacker-green mr-2 font-bold select-none animate-pulse">
        >_
      </div>
      <input
        ref={inputRef}
        type="text"
        value={input}
        onChange={(e) => setInput(e.target.value)}
        disabled={disabled}
        className="flex-1 bg-transparent border-none outline-none text-gray-100 font-mono text-base sm:text-lg placeholder-gray-800 caret-hacker-green"
        placeholder={disabled ? "NO CARRIER..." : "Enter message or /cmd..."}
        autoComplete="off"
        spellCheck="false"
      />
      <button 
        type="submit"
        disabled={!input.trim() || disabled}
        className="ml-2 text-hacker-green hover:text-white transition-colors disabled:opacity-10"
      >
        <PaperAirplaneIcon className="w-5 h-5 sm:w-6 sm:h-6 -rotate-90" />
      </button>
    </form>
  );
};

export default TerminalInput;